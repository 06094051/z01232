Fenced code living in an indented environment is correctly highlighted:

1. run this command to do this:

    ```
some command
    ```

2. Subsequent list items are correctly highlighted.

Fenced code block with language:

```ruby
def f
  0
end
```
